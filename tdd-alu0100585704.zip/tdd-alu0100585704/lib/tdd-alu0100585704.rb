require "tdd-alu0100585704/version"
require "tdd-alu0100585704/alimentos"
require "tdd-alu0100585704/listas"
require "tdd-alu0100585704/platoN"
require "tdd-alu0100585704/platoCompleto"

module TDDALU0100585704
  class Error < StandardError; end
  # Your code goes here...

end
