
Practica 6: Lenguajes y Paradigmas de la Programación
Autor: Juan Siverio Rojas

Práctica sobre la metodología de programación por TDD (pruebas dirigidas por desarrollo).
Valor energético de diferentes alimentos e impacto ambiental producido.

